#include <osgDB/ReadFile>
#include <osgUtil/Optimizer>
#include <osg/CoordinateSystemNode>

#include <osg/Switch>
#include <osgText/Text>

#include <osgViewer/Viewer>
#include <osgViewer/ViewerEventHandlers>

#include <osgGA/TrackballManipulator>
#include <osgGA/FlightManipulator>
#include <osgGA/DriveManipulator>
#include <osgGA/KeySwitchMatrixManipulator>
#include <osgGA/StateSetManipulator>
#include <osgGA/AnimationPathManipulator>
#include <osgGA/TerrainManipulator>

#include <iostream>

int main(int argc, char** argv)
{

    osgViewer::Viewer viewer;

    osg::ref_ptr<osgGA::TrackballManipulator> manip = new osgGA::TrackballManipulator;
    viewer.setCameraManipulator(manip);

    viewer.addEventHandler( new osgGA::StateSetManipulator(viewer.getCamera()->getOrCreateStateSet()) );
    viewer.addEventHandler(new osgViewer::ThreadingHandler);
    viewer.addEventHandler(new osgViewer::WindowSizeHandler);
    viewer.addEventHandler(new osgViewer::StatsHandler);


    osgDB::Options* opt = new osgDB::Options;
    opt->setOptionString("noRotation");

    osg::ref_ptr<osg::Node> node = osgDB::readNodeFile("Data2.obj", opt);

    if (!node)
    {
        std::cout <<": No data loaded" << std::endl;
        return 1;
    }

    viewer.setSceneData( node.get() );

    return viewer.run();
}
