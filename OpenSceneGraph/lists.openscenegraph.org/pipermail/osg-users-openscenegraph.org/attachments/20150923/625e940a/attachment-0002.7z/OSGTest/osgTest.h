#ifndef OIGSCENE_H
#define OIGSCENE_H

#include "viewerThread.h"
#include <vector>

class osgScene
{
public:
    osgScene(int argc, char *argv[]);

    ViewerThread *thread;

private:
    typedef std::vector<ViewerThread*> vthreads;
    vthreads threads;

};

#endif // OIGSCENE_H

