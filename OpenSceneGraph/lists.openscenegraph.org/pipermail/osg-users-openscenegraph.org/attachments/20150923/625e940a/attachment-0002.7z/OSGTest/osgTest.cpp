#include "osgTest.h"
#include <unistd.h>

bool osgTest=false;

#define THREADCOUNT 3

osgScene::osgScene( int argc, char *argv[] )
{
    int x=0;
    for(;x<THREADCOUNT;x++)
    {
        thread = new ViewerThread(x, argc, argv);
        thread->startThread();
        threads.push_back(thread);
        sleep(2);
    }

    sleep(5);
    for(vthreads::iterator it=threads.begin(); it!=threads.end();++it)
    {
        (*it)->cancel();
    }
    osgTest = true;
}


int main(int argc, char *argv[])
{
    osgScene *scene = new osgScene(argc, argv);

    while(!osgTest)
        ;
    return 0;
}
